package ISOFT2_B05.Pr1;



public class Problema1 {
    
    private Fecha fecha;
    
    public Problema1(int anio,int mes, int dia){
        
        this.setFecha(anio,mes,dia);
               
    }
    
    public void setFecha(int anio,int mes, int dia) {
    	if(dia<0 || mes<0 || anio<0){
            throw new IllegalArgumentException("error en los argumentos, no se permiten nº negativos");
        }
    	this.fecha = new Fecha(anio,mes,dia);
    }
    
    public void actualizarFecha(int anio,int mes, int dia) {
    	if(dia<0 || mes<0 || anio<0){
            throw new IllegalArgumentException("error en los argumentos, no se permiten nº negativos");
        }
    	
    	this.fecha.setAnio(anio);
    	this.fecha.setMes(mes);
    	this.fecha.setDia(dia);
    }
    
    
    public boolean es_bisiesto(){
        boolean bisiesto=false;
        
        int ultimasCifras = this.fecha.getAnio() % 100;
        int anio = this.fecha.getAnio();
        if(ultimasCifras % 4 == 0 && anio % 100 != 0)
            bisiesto = true;
        else if(ultimasCifras % 4 == 0 && anio % 100 == 0 && anio % 400 == 0)
            bisiesto = true;
        
        return bisiesto;
    }
    
    
}

class Fecha{
	private int anio, mes, dia;
	
	public Fecha(int anio,int mes,int dia){
		setAnio(anio);
		setMes(mes);
		setDia(dia);
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}
	
	
	
	
}